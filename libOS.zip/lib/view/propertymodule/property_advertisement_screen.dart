import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import '../../controller/app_color.dart';
import '../../controller/app_constant.dart';
import '../../controller/app_font.dart';
import '../../controller/app_header.dart';
import '../../controller/app_image.dart';
import '../../controller/app_language.dart';

class PropertyAdvertisementScreen extends StatefulWidget {
  final String tripId;
  const PropertyAdvertisementScreen({super.key, required this.tripId});

  @override
  State<PropertyAdvertisementScreen> createState() =>
      _PropertyAdvertisementScreenState();
}

class _PropertyAdvertisementScreenState
    extends State<PropertyAdvertisementScreen> {
  int selectedImageInd = 0;

  // ── PROTOTYPE / DUMMY DATA ─────────────────────────────────────────────────
  List<Map<String, dynamic>> tripImages = [
    {"image": AppImage.house1Icon},
    {"image": AppImage.house2Icon},
    {"image": AppImage.house3Icon},
    {"image": AppImage.house1Icon},
  ];

  Map<String, dynamic> adDetails = {
    // Basic
    "boat_name_english": "The Greenleaf Inn",
    "rating": "4.5",
    "property_type": "Villa",
    "city_name": "South Kuta",

    // Detail rows — exact as image
    "guests": "4 Adult · 2 Child",
    "rooms": "4 Rooms",
    "washrooms": "6 Washrooms",
    "halls": "2 Halls",
    "outdoor_seating": "1 Large Garden",
    "pool": "1 Private Swimming Pool",
    "guard": "Mohhamd",

    // Pricing
    "one_day": 200,
    "weekday": 250,
    "weekend": 300,
    "full_week": 400,

    "coupon_code": "NA",
    "coupon_discount": 0.00,
    "discount": 0.00,

    // Other
    "pet_friendly": "No",
    "cancle_day": 0,

    // Description
    "place_offer": AppLanguage.blueWaterisText[language],
  };

  @override
  Widget build(BuildContext context) => _buildUIScreen(context);

  // ===========================================================================
  Widget _buildUIScreen(BuildContext context) {
    final double sw = MediaQuery.of(context).size.width;
    final double sh = MediaQuery.of(context).size.height;
    final size = MediaQuery.of(context).size;

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    return Scaffold(
      backgroundColor: AppColor.secondaryColor,
      body: Directionality(
        textDirection:
            language == 1 ? ui.TextDirection.rtl : ui.TextDirection.ltr,
        child: SizedBox(
          width: sw,
          height: sh,
          child: Column(
            children: [
              // ── ORANGE HEADER ──────────────────────────────────────────────
              AppHeaderOrange(
                text: AppLanguage.advertisementText[language],
                onPress: () => Navigator.pop(context),
              ),

              // ── SCROLLABLE BODY ────────────────────────────────────────────
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: size.width * 0.02),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: sh * 0.04),

                        // ── MAIN IMAGE ───────────────────────────────────────
                        if (tripImages.isNotEmpty)
                          Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.asset(
                                tripImages[selectedImageInd]['image'],
                                width: sw * 0.90,
                                height: sw > 600 ? sh * 0.30 : sh * 0.22,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                    _imagePlaceholder(sw, sh),
                              ),
                            ),
                          ),

                        SizedBox(height: sh * 0.015),

                        // ── THUMBNAIL ROW ────────────────────────────────────
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.03),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(tripImages.length, (i) {
                              final selected = selectedImageInd == i;
                              final itemWidth = (sw * 0.90 -
                                      ((tripImages.length - 1) * (sw * 0.02))) /
                                  tripImages.length;
                              return GestureDetector(
                                onTap: () =>
                                    setState(() => selectedImageInd = i),
                                child: Container(
                                  margin: EdgeInsets.only(
                                    right: i != tripImages.length - 1
                                        ? sw * 0.02
                                        : 0,
                                  ),
                                  width: itemWidth,
                                  height: itemWidth,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: selected
                                        ? Border.all(
                                            color: AppColor.themeColor,
                                            width: 2)
                                        : Border.all(
                                            color: Colors.transparent,
                                            width: 2),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(9),
                                    child: Image.asset(
                                      tripImages[i]['image'],
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        color: Colors.grey.shade300,
                                        child: const Icon(Icons.image,
                                            color: Colors.grey),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                          ),
                        ),

                        SizedBox(height: sh * 0.02),

                        // ── PROPERTY NAME + TYPE + LOCATION ─────────────────
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Name
                              Text(
                                adDetails['boat_name_english'],
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: AppColor.primaryColor,
                                  fontFamily: AppFont.fontFamily,
                                ),
                              ),
                              const SizedBox(height: 4),

                              // Property type
                              Text(
                                adDetails['property_type'],
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400,
                                  color: AppColor.primaryColor,
                                  fontFamily: AppFont.fontFamily,
                                ),
                              ),
                              const SizedBox(height: 6),

                              // City with red pin
                              Row(
                                children: [
                                  Image.asset(
                                    './assets/icons/location.png',
                                    height: size.width * 4.5 / 100,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    adDetails['city_name'],
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: AppColor.primaryColor,
                                      fontFamily: AppFont.fontFamily,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: sh * 0.02),

                        // ── DETAIL ROWS ──────────────────────────────────────
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          child: Column(
                            children: [
                              _detailRow(AppLanguage.guestsText[language],
                                  adDetails['guests']),
                              _detailRow(AppLanguage.roomsText[language],
                                  adDetails['rooms']),
                              _detailRow(AppLanguage.washroomsText[language],
                                  adDetails['washrooms']),
                              _detailRow(AppLanguage.hallsText[language],
                                  adDetails['halls']),
                              _detailRow(
                                  AppLanguage.outdoorSeatingText[language],
                                  adDetails['outdoor_seating']),
                              _detailRow(AppLanguage.poolText[language],
                                  adDetails['pool']),
                              _detailRow(AppLanguage.guardText[language],
                                  adDetails['guard']),
                              _detailRow(AppLanguage.oneDayText[language],
                                  "${adDetails['one_day']} KWD"),
                              _detailRow(AppLanguage.weekdayText[language],
                                  "${adDetails['weekday']} KWD"),
                              _detailRow(AppLanguage.weekendText[language],
                                  "${adDetails['weekend']} KWD"),
                              _detailRow(AppLanguage.fullWeekText[language],
                                  "${adDetails['full_week']} KWD"),
                              _detailRow(
                                  AppLanguage.couponCodeCOLONText[language],
                                  adDetails['coupon_code']),
                              _detailRow(
                                  AppLanguage.couponDiscountCOLONText[language],
                                  "${(adDetails['coupon_discount'] as double).toStringAsFixed(2)}%"),
                              _detailRow(
                                  AppLanguage.discountCOLONText[language],
                                  "${(adDetails['discount'] as double).toStringAsFixed(2)}%"),
                              _detailRow(
                                  AppLanguage.petFriendlyCOLONText[language],
                                  adDetails['pet_friendly']),
                              _detailRow(
                                  AppLanguage
                                      .cancellationTimeCOLONText[language],
                                  "${adDetails['cancle_day']} ${AppLanguage.daysCOLONText[language]}"),
                            ],
                          ),
                        ),
                        SizedBox(height: sh * 0.02),
                        // ── DESCRIPTION ──────────────────────────────────────
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Description",
                                style: TextStyle(
                                  fontSize: 21,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.black2A2AColor,
                                  fontFamily: AppFont.fontFamily,
                                ),
                              ),
                              SizedBox(height: sh * 0.01),
                              Text(
                                adDetails['place_offer'] ?? "",
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: AppColor.primaryColor,
                                  fontFamily: AppFont.fontFamily,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: sh * 0.02),

                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          child: Text(
                            AppLanguage.whatThisPlaceOffersText[language],
                            style: const TextStyle(
                              fontSize: 21,
                              fontFamily: AppFont.fontFamily,
                              fontWeight: FontWeight.w500,
                              color: AppColor.black2A2AColor,
                            ),
                          ),
                        ),
                        SizedBox(height: sh * 0.01),

                        Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage.tvText[language],
                                        icon: AppImage.tv)),
                                SizedBox(width: size.width * 0.04),
                                Expanded(
                                    child: FeatureItem(
                                        title:
                                            AppLanguage.beddingText[language],
                                        icon: AppImage.bedding)),
                              ],
                            ),
                            SizedBox(height: size.height * 0.01),
                            Row(
                              children: [
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage.wifiText[language],
                                        icon: AppImage.wifi)),
                                SizedBox(width: size.width * 0.04),
                                Expanded(
                                    child: FeatureItem(
                                        title:
                                            AppLanguage.microwaveText[language],
                                        icon: AppImage.microwave)),
                              ],
                            ),
                            SizedBox(height: size.height * 0.01),
                            Row(
                              children: [
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage.acText[language],
                                        icon: AppImage.acIcon)),
                                SizedBox(width: size.width * 0.04),
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage.kettleText[language],
                                        icon: AppImage.kettle)),
                              ],
                            ),
                            SizedBox(height: size.height * 0.01),
                            Row(
                              children: [
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage.fridgeText[language],
                                        icon: AppImage.fridge)),
                                SizedBox(width: size.width * 0.04),
                                Expanded(
                                    child: FeatureItem(
                                        title: AppLanguage
                                            .coffeeMachineText[language],
                                        icon: AppImage.coffeeMachine)),
                              ],
                            ),
                          ],
                        ),

                        SizedBox(height: sh * 0.02),

                        SizedBox(height: sh * 0.12),
                      ],
                    ),
                  ),
                ),
              ),

              const NoInternetBanner(),
            ],
          ),
        ),
      ),
    );
  }

  // ── PLAIN TEXT DETAIL ROW ───────────────────────────────────────────────────
  Widget _detailRow(String label, String value) {
    // final double sw = MediaQuery.of(context).size.width;
    final double sh = MediaQuery.of(context).size.height;
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
                fontFamily: AppFont.fontFamily,
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
                fontFamily: AppFont.fontFamily,
              ),
            ),
          ],
        ),
        SizedBox(height: sh * 0.018),
      ],
    );
  }

  // ── IMAGE PLACEHOLDER ────────────────────────────────────────────────────────
  Widget _imagePlaceholder(double sw, double sh) {
    return Container(
      width: sw * 0.90,
      height: sh * 0.22,
      decoration: BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Icon(Icons.image, size: 60, color: Colors.grey),
    );
  }
}

// ── FEATURE ITEM WIDGET ───────────────────────────────────────────────────────
class FeatureItem extends StatelessWidget {
  final String title;
  final String icon;
  final Color? iconColor;
  final Color? textColor;

  const FeatureItem({
    super.key,
    required this.title,
    required this.icon,
    this.iconColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
      child: Row(
        children: [
          Image.asset(
            icon,
            height: size.width * 0.035,
            color: iconColor ?? Colors.grey.shade700,
          ),
          SizedBox(width: size.width * 0.02),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontFamily: AppFont.fontFamily,
                fontWeight: FontWeight.w500,
                color: textColor ?? Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
