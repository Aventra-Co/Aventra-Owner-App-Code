import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../../controller/app_config_provider.dart';
import '../../controller/app_loader.dart';
import '../../controller/app_snack_bar_toast_message.dart';
import '../authentication/login_screen.dart';
import '../../controller/textinput.dart';
import '../../controller/app_button.dart';
import '../../controller/app_color.dart';
import '../../controller/app_constant.dart';
import '../../controller/app_font.dart';
import '../../controller/app_image.dart';
import '../../controller/app_language.dart';
import 'manageBoatScreen.dart';

class EditBoatDetailsScreen extends StatefulWidget {
  static String routeName = './EditBoatDetailsScreen';
  final String boatId;
  final String boatName;
  final String boatBrand;
  final String registration;
  final String year;
  final String size;
  final String capacity;
  final String cabin;
  final String toilet;

  const EditBoatDetailsScreen({
    super.key,
    required this.boatId,
    required this.boatName,
    required this.registration,
    required this.year,
    required this.size,
    required this.capacity,
    required this.cabin,
    required this.toilet,
    required this.boatBrand,
  });

  @override
  State<EditBoatDetailsScreen> createState() => _BoatDetailsScreenState();
}

class _BoatDetailsScreenState extends State<EditBoatDetailsScreen> {
  TextEditingController searchTextController = TextEditingController();
  TextEditingController boatNameTextEditingController = TextEditingController();
  TextEditingController boatRegistrationNumberTextEditingController =
      TextEditingController();
  TextEditingController boatCapacityTextEditingController =
      TextEditingController();
  TextEditingController boatSizeTextEditingController = TextEditingController();
  TextEditingController cabinsTextEditingController = TextEditingController();
  TextEditingController toiletTextEditingController = TextEditingController();
  TextEditingController boatBrandTextEditingController =
      TextEditingController();
  TextEditingController boatYearTextEditingController = TextEditingController();
  DateTime? selectedDate;
  var sendDate = "";
  bool isApiCalling = false;

  //==========================DATE FUNCTION=======================//
  Future<void> _selectDate(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime(int.parse(widget.year), 1, 1),
      firstDate: DateTime(int.parse(widget.year)),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      var sendDate1 = DateFormat('yyyy').format(picked);
      boatYearTextEditingController.text = DateFormat('yyyy').format(picked);
      setState(() {
        selectedDate = picked;
        sendDate = sendDate1;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    boatNameTextEditingController.text = widget.boatName;
    boatBrandTextEditingController.text = widget.boatBrand;
    boatRegistrationNumberTextEditingController.text = widget.registration;
    boatSizeTextEditingController.text = widget.size;
    boatCapacityTextEditingController.text = widget.capacity;
    cabinsTextEditingController.text = widget.cabin;
    toiletTextEditingController.text = widget.toilet;
    boatYearTextEditingController.text = widget.year;
    sendDate = widget.year;
  }

  //-------------------------------EDIT Boat VALIDATION---------------------------------//
  void editBoatValidation(
    String boatName,
    String registration,
    String boatBrand,
    String year,
    String size,
    String capacity,
    String cabins,
    String toilet,
  ) {
    if (boatName.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.boatNameMsg[language]);
      return;
    } else if (registration.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.registrationMsg[language]);
      return;
    } else if (boatBrand.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.boatBrandMsg[language]);
      return;
    } else if (year.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.boatYearMsg[language]);
      return;
    } else if (size.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.boatSizeMsg[language]);
      return;
    } else if (capacity.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.boatCapacityMsg[language]);
      return;
    } else if (cabins.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.cabinsMsg[language]);
      return;
    } else if (toilet.isEmpty) {
      SnackBarToastMessage.showSnackBar(
          context, AppLanguage.toiletMsg[language]);
      return;
    } else {
      // If validation passes, call the API
      editBoatApiCall();
    }
  }

//------------------------EDIT boat API CALL--------------------------------//
  editBoatApiCall() async {
    setState(() {
      isApiCalling = true;
    });

    Uri url = Uri.parse("${AppConfigProvider.apiUrl}edit_boat");

    print("Url===> $url");

    try {
      http.MultipartRequest formData = http.MultipartRequest('POST', url);
      formData.fields['boat_id'] = widget.boatId;
      formData.fields['boat_name_english'] = boatNameTextEditingController.text;
      formData.fields['boat_brand'] = boatBrandTextEditingController.text;
      formData.fields['boat_registration_number'] =
          boatRegistrationNumberTextEditingController.text;
      formData.fields['boat_year'] = sendDate.toString();
      formData.fields['boat_size'] = boatSizeTextEditingController.text;
      formData.fields['boat_capacity'] = boatCapacityTextEditingController.text;
      formData.fields['cabins'] = cabinsTextEditingController.text;
      formData.fields['toilet'] = toiletTextEditingController.text;

      // if (_imageSelect != null) {
      //   XFile image1 = _imageSelect!;
      //   List<int> imageBytes = await image1.readAsBytes();
      //   http.MultipartFile imageFile = http.MultipartFile.fromBytes(
      //       'image', imageBytes,
      //       filename: 'image.jpg', contentType: MediaType('image', 'jpg'));

      //   formData.files.add(imageFile);
      // } else {
      //   formData.fields['image'] = "";
      // }

      log("response--==> ${formData.fields}");
      // print("response--==> ${formData.files}");
      http.StreamedResponse response = await formData.send();
      print("response--==> $response");
      var responseString = await response.stream.toBytes();
      var res = jsonDecode(utf8.decode(responseString));

      if (response.statusCode == 200) {
        print("res : $res");
        if (res['success'] == true) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ManageBoatScreen(),
            ),
          );
          SnackBarToastMessage.showSnackBar(context, res['msg'][language]);
          setState(() {
            isApiCalling = false;
          });
        } else {
          setState(() {
            isApiCalling = false;
          });
          // ignore: use_build_context_synchronously
          SnackBarToastMessage.showSnackBar(context, res['msg'][language]);
          if (res['active_status'] == 0) {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Login()));
          }
        }
      } else {
        setState(() {
          isApiCalling = false;
        });
      }
    } catch (e) {
      setState(() {
        isApiCalling = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
        inAsyncCall: isApiCalling,
        opacity: 0.5,
        child: _buildUIScreen(context));
  }

  Widget _buildUIScreen(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light));
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        backgroundColor: AppColor.secondaryColor,
        body: Container(
          width: MediaQuery.of(context).size.width * 100 / 100,
          height: MediaQuery.of(context).size.height * 100 / 100,
          color: AppColor.secondaryColor,
          child: Column(
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 100 / 100,
                height: MediaQuery.of(context).size.height * 20 / 100,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(AppImage.headerBgImage),
                        fit: BoxFit.cover),
                    color: AppColor.themeColor,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50))),
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 4 / 100,
                    ),

                    //manage text
                    Container(
                      width: MediaQuery.of(context).size.width * 100 / 100,
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Container(
                              width:
                                  MediaQuery.of(context).size.width * 15 / 100,
                              height:
                                  MediaQuery.of(context).size.width * 8 / 100,
                              child: Image.asset(
                                AppImage.leftArrowIcon,
                                color: AppColor.secondaryColor,
                              ),
                            ),
                          ),
                          Container(
                            child: Text(
                              AppLanguage.editDetailsText[language],
                              style: const TextStyle(
                                  color: AppColor.secondaryColor,
                                  fontFamily: AppFont.fontFamily,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 15 / 100,
                            height: MediaQuery.of(context).size.width * 6 / 100,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                  child: SingleChildScrollView(
                child: Column(children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 2 / 100,
                  ),
                  //!===Enter Boat Name====
                  CustomTextFormFieldBlackWidth(
                    controller: boatNameTextEditingController,
                    hintText: AppLanguage.enterBoatNameText[language],
                    keyboardtype: TextInputType.name,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 1 / 100,
                  ),

                  //!=== Enter Boat Registration Number ===
                  CustomTextFormFieldBlackWidth(
                    controller: boatRegistrationNumberTextEditingController,
                    hintText:
                        AppLanguage.enterBoatRegistrationNumberText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 1 / 100,
                  ),

                  //!=== Enter Boat Brand ===
                  CustomTextFormFieldBlackWidth(
                    controller: boatBrandTextEditingController,
                    hintText: AppLanguage.enterBoatBrandText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 1 / 100,
                  ),

                  //!-----------boat year field---------------
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 90 / 100,
                    height: MediaQuery.of(context).size.height * 6 / 100,
                    child: TextFormField(
                      style: const TextStyle(
                          height: 1.1,
                          color: AppColor.primaryColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w400),
                      controller: boatYearTextEditingController,
                      textAlignVertical: TextAlignVertical.center,
                      decoration: InputDecoration(
                          hintText: AppLanguage.boatYearText[language],
                          border: const UnderlineInputBorder(
                            // Use UnderlineInputBorder
                            borderSide: BorderSide(color: AppColor.boaderColor),
                          ),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: AppColor.boaderColor),
                          ),
                          focusedBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppColor.themeColor, width: 1),
                          ),
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 9),
                          fillColor: Colors.transparent,
                          filled: true,
                          counterText: '',
                          hintStyle: AppConstant.textFilledStyle,
                          suffixIcon: IconButton(
                            icon: Container(
                              alignment: Alignment.centerRight,
                              width:
                                  MediaQuery.of(context).size.width * 20 / 100,
                              height:
                                  MediaQuery.of(context).size.width * 6 / 100,
                              child: Image.asset(
                                AppImage.calenderImage,
                              ),
                            ),
                            onPressed: () {
                              _selectDate(context);
                            },
                          )),
                      readOnly: true,
                      onTap: () => _selectDate(context),
                    ),
                  ),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 1 / 100),

                  //!=== Enter Boat Size ==
                  CustomTextFormFieldBlackWidth(
                    controller: boatSizeTextEditingController,
                    hintText: AppLanguage.enterBoatSizeText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 1 / 100),

                  //!=== Enter Boat Capacity ===
                  CustomTextFormFieldBlackWidth(
                    controller: boatCapacityTextEditingController,
                    hintText: AppLanguage.enterBoatCapacityText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 1 / 100),

                  //!=== Enter Cabins ===
                  CustomTextFormFieldBlackWidth(
                    controller: cabinsTextEditingController,
                    hintText: AppLanguage.enterCabinsText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 1 / 100),

                  //!=== Enter Toilet ===
                  CustomTextFormFieldBlackWidth(
                    controller: toiletTextEditingController,
                    hintText: AppLanguage.enterToiletText[language],
                    keyboardtype: TextInputType.number,
                    maxLength: 50,
                    fillColorStatus: 0,
                    readOnly: false,
                    width: MediaQuery.of(context).size.width * 90 / 100,
                  ),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 6 / 100),

                  //!=== Add Boat Image Text ===
                  // Container(
                  //   width: MediaQuery.of(context).size.width * 90 / 100,
                  //   child: Text(
                  //     AppLanguage.addBoatImageText[language],
                  //     style: const TextStyle(
                  //         color: AppColor.textColor,
                  //         fontFamily: AppFont.fontFamily,
                  //         fontWeight: FontWeight.w400,
                  //         fontSize: 20),
                  //   ),
                  // ),
                  // SizedBox(
                  //     height: MediaQuery.of(context).size.height * 1 / 100),
                  // Container(
                  //   width: MediaQuery.of(context).size.width * 90 / 100,
                  //   height: MediaQuery.of(context).size.height * 15 / 100,
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(10),
                  //     border: Border.all(
                  //       color: AppColor.boaderColor,
                  //     ),
                  //   ),
                  //   child: ClipRRect(
                  //     borderRadius: BorderRadius.circular(10),
                  //     child: Image.asset(
                  //       AppImage.boatImage,
                  //       fit: BoxFit.cover,
                  //     ),
                  //   ),
                  // ),
                  // SizedBox(
                  //     height: MediaQuery.of(context).size.height * 2 / 100),

                  //!=== Button Submit ===
                  AppButton(
                      text: AppLanguage.submitText[language],
                      onPress: () {
                        editBoatValidation(
                            boatNameTextEditingController.text,
                            boatRegistrationNumberTextEditingController.text,
                            boatBrandTextEditingController.text,
                            boatYearTextEditingController.text,
                            boatSizeTextEditingController.text,
                            boatCapacityTextEditingController.text,
                            cabinsTextEditingController.text,
                            toiletTextEditingController.text);
                      }),
                  SizedBox(
                      height: MediaQuery.of(context).size.height * 3 / 100),
                ]),
              ))
            ,const NoInternetBanner(),
            ],
          ),
        ),
      ),
    );
  }
}
