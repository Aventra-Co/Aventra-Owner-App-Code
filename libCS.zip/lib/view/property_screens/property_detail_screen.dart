import 'package:boatapp/controller/app_color.dart';
import 'package:boatapp/controller/app_constant.dart';
import 'package:boatapp/controller/app_font.dart';
import 'package:boatapp/controller/app_header.dart';
import 'package:boatapp/controller/app_image.dart';
import 'package:boatapp/controller/app_language.dart';
import 'package:boatapp/view/property_screens/cancellation_policy_screen.dart';
import 'package:boatapp/view/property_screens/propert_booking_details.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

class PropertyDetailsScreen extends StatefulWidget {
  const PropertyDetailsScreen({super.key});

  @override
  State<PropertyDetailsScreen> createState() => _PropertyDetailsScreenState();
}

class _PropertyDetailsScreenState extends State<PropertyDetailsScreen> {
  int currentImageIndex = 0;
  int adults = 6;
  int children = 4;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  // ── Time slot state ───────────────────────────────────────────────────
  String? _selectedTime;
  final List<String> _timeSlots = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM',
    '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM',
  ];
  // ─────────────────────────────────────────────────────────────────────

  // Available dates (blue dots)
  final Set<DateTime> _availableDates = {
    DateTime(2025, 1, 9),
    DateTime(2025, 1, 15),
    DateTime(2025, 1, 22),
    DateTime(2025, 1, 28),
  };

  String selectedPrice = 'One day (2pm till next day 12 afternoon)';

  final List<Map<String, String>> priceOptions = [
    {'title': 'One day (2pm till next day 12 afternoon)', 'price': '200 KWD'},
    {'title': 'Weekday (Sun-Wed)',                        'price': '300 KWD'},
    {'title': 'Weekend (Thu-Sat)',                        'price': '350 KWD'},
    {'title': 'Full week (Sun-Sat)',                      'price': '500 KWD'},
  ];

  final List<String> amenities = [
    'TV', 'Wifi', 'AC', 'Fridge',
    'Bedding', 'Microwave', 'Kettle', 'Coffee Machine',
  ];

  int adultCount = 0;
  int childCount = 4;

  DateTime _normalise(DateTime d) => DateTime(d.year, d.month, d.day);

  bool _isAvailable(DateTime day) =>
      _availableDates.any((d) => isSameDay(d, day));

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: size.width * 0.05, vertical: size.height * 0.02),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppHeader(
                    text: AppLanguage.detailsText[language],
                    onPress: () => Navigator.pop(context)),

                SizedBox(height: size.height * 0.05),

                // Main image
                ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(AppImage.greenLeafImage2)),

                SizedBox(height: size.height * 0.03),

                // Sub images row
                Row(
                  children: [
                    _subImg(size, AppImage.subImage1),
                    SizedBox(width: size.width * 0.02),
                    _subImg(size, AppImage.subImage2),
                    SizedBox(width: size.width * 0.02),
                    _subImg(size, AppImage.subImage3),
                    SizedBox(width: size.width * 0.02),
                    _subImg(size, AppImage.subImage4),
                  ],
                ),

                SizedBox(height: size.height * 0.05),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title
                    Text(
                      AppLanguage.greenLeafInnText[language],
                      style: const TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppFont.fontFamily,
                      ),
                    ),
                    const Text(
                      'Villa',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Row(
                      children: [
                        Image.asset(AppImage.redLocationIcon,
                            width: size.width * 0.04, height: size.height * 0.04),
                        SizedBox(width: size.width * 0.01),
                        Text(
                          'South kuta',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: AppFont.fontFamily,
                            fontWeight: FontWeight.w400,
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: size.height * 0.02),

                    _detailGrid(),
                    SizedBox(height: size.height * 0.04),

                    // Description
                    const Text(
                      'Description',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      AppLanguage.blueNatureText[language],
                      style: TextStyle(
                        fontSize: 16,
                        fontFamily: AppFont.fontFamily,
                        color: Colors.grey.shade700,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),

                    // What this place offers
                    Text(
                      AppLanguage.whatThisplaceOfferText[language],
                      style: const TextStyle(
                        fontSize: 21.33,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    _amenitiesGrid(),
                    SizedBox(height: size.height * 0.03),

                    // Price
                    const Text(
                      'Price',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        fontFamily: AppFont.fontFamily,
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),

                    ...priceOptions.map((option) => _priceOption(
                          title: option['title']!,
                          price: option['price']!,
                          isSelected: selectedPrice == option['title'],
                          onTap: () =>
                              setState(() => selectedPrice = option['title']!),
                        )),

                    // Cancellation policy
                    Row(
                      children: [
                        Image.asset(AppImage.cancellationPolicyicon,
                            width: size.width * 0.04, height: size.height * 0.04),
                        TextButton(
                          onPressed: _showCancellationPolicyDialog,
                          child: Text(
                            'Cancellation policy',
                            style: TextStyle(
                              fontFamily: AppFont.fontFamily,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: AppColor.themeColor,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: size.height * 1.5 / 100),

                    // ── LEGEND ──────────────────────────────────────────
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _legendItem(AppLanguage.bookNowText[language], null),
                        SizedBox(width: size.width * 0.08),
                        _legendItem('Availability', const Color(0xFF009FE3)),
                        _legendItem('Selected', AppColor.themeColor),
                      ],
                    ),

                    SizedBox(height: size.height * 0.02),

                    // ── CALENDAR (Figma style) ───────────────────────────
                    _buildCalendar(size),

                    SizedBox(height: size.height * 0.03),

                    // ── TIME SLOT PICKER ────────────────────────────────

                    SizedBox(height: size.height * 0.03),

                    // Guests
                    Text(
                      AppLanguage.guestsext[language],
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        fontFamily: AppFont.fontFamily,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: size.height * 0.012),

                    _guestCounterRow(context,
                        label: 'Adult',
                        count: adultCount,
                        onDecrement: () {
                          if (adultCount > 0) setState(() => adultCount--);
                        },
                        onIncrement: () => setState(() => adultCount++)),

                    Divider(color: Colors.grey.shade200, height: size.height * 0.04),

                    _guestCounterRow(context,
                        label: 'Child',
                        count: childCount,
                        onDecrement: () {
                          if (childCount > 0) setState(() => childCount--);
                        },
                        onIncrement: () => setState(() => childCount++)),

                    Divider(color: AppColor.boaderColor),
                    SizedBox(height: size.height * 0.06),

                    // Book Now button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColor.themeColor,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25)),
                        ),
                        child: const Text(
                          'Book Now',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: AppFont.fontFamily,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: size.height * 0.04),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Sub image helper ─────────────────────────────────────────────────
  Widget _subImg(Size size, String path) {
    return Expanded(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.asset(path, height: size.height * 0.1, fit: BoxFit.cover),
      ),
    );
  }

  // ────────────────────────────────────────────────────────────────────────
  // CALENDAR — matches Figma design
  // ────────────────────────────────────────────────────────────────────────
  Widget _buildCalendar(Size size) {
    return TableCalendar(
      firstDay: DateTime.utc(2020, 1, 1),
      lastDay: DateTime.utc(2030, 12, 31),
      focusedDay: _focusedDay,
      selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
      onDaySelected: (selectedDay, focusedDay) {
        setState(() {
          _selectedDay = selectedDay;
          _focusedDay = focusedDay;
        });
      },
      onPageChanged: (focusedDay) => setState(() => _focusedDay = focusedDay),
      calendarFormat: CalendarFormat.month,
      availableCalendarFormats: const {CalendarFormat.month: 'Month'},

      // ── Custom day cells ──────────────────────────────────────────────
      calendarBuilders: CalendarBuilders(
        // Centered "Month Year" header with chevrons on both sides
        headerTitleBuilder: (context, date) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Left chevron
                GestureDetector(
                  onTap: () => setState(() {
                    _focusedDay = DateTime(
                        _focusedDay.year, _focusedDay.month - 1, 1);
                  }),
                
                    child: Icon(Icons.chevron_left,
                        color: AppColor.primaryColor, size: 22),
                  
                ),
            
                SizedBox(width: size.width*0.03,),
            
                // Month + Year centred
                Text(
                  DateFormat('MMMM yyyy').format(date),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black,
                  ),
                ),
            
                    SizedBox(width: size.width*0.03,),
            
                // Right chevron
                GestureDetector(
                  onTap: () => setState(() {
                    _focusedDay = DateTime(
                        _focusedDay.year, _focusedDay.month + 1, 1);
                  }),
                 
                    child: Icon(Icons.chevron_right,
                        color: AppColor.primaryColor, size: 22),
                  
                ),
              ],
            ),
          );
        },


        // Default day cell
        defaultBuilder: (context, day, focusedDay) {
          if (_isAvailable(day)) {
            return _dayCell(
              day,
              bgColor: const Color(0xFF009FE3),
              textColor: Colors.white,
            );
          }
          return _dayCell(day, bgColor: null, textColor: Colors.black87);
        },

        // Today (unselected)
        todayBuilder: (context, day, focusedDay) {
          return _dayCell(
            day,
            bgColor: AppColor.themeColor.withOpacity(0.15),
            textColor: Colors.black87,
            borderColor: AppColor.themeColor,
          );
        },

        // Selected day
        selectedBuilder: (context, day, focusedDay) {
          return _dayCell(
            day,
            bgColor: AppColor.themeColor,
            textColor: Colors.white,
          );
        },

        // Outside-month days
        outsideBuilder: (context, day, focusedDay) {
          return _dayCell(day, bgColor: null, textColor: Colors.grey.shade400);
        },
      ),

      // ── Header ───────────────────────────────────────────────────────
      headerStyle: HeaderStyle(
        formatButtonVisible: false,
        titleCentered: true,
        headerPadding:
            EdgeInsets.symmetric(vertical: size.height * 0.015),
        // Hide the built-in chevrons — we draw our own inside headerTitleBuilder
        leftChevronIcon: const SizedBox.shrink(),
        rightChevronIcon: const SizedBox.shrink(),
        leftChevronMargin: EdgeInsets.zero,
        rightChevronMargin: EdgeInsets.zero,
        leftChevronPadding: EdgeInsets.zero,
        rightChevronPadding: EdgeInsets.zero,
      ),

      // ── Day-of-week row: plain dark text, no background ───────────────
      daysOfWeekStyle: DaysOfWeekStyle(
        weekdayStyle: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          fontFamily: AppFont.fontFamily,
          color: Colors.grey.shade600,
        ),
        weekendStyle: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          fontFamily: AppFont.fontFamily,
          color: Colors.grey.shade600,
        ),
        // Transparent row — no colour block
        decoration: const BoxDecoration(color: Colors.transparent),
      ),

      // ── Calendar style (fallback / spacing) ───────────────────────────
      calendarStyle: const CalendarStyle(
        // All actual day rendering is handled in calendarBuilders above
        cellMargin: EdgeInsets.all(5),
        outsideDaysVisible: true,
      ),
    );
  }

  /// Shared day cell builder: circle with optional bg, border, text colour.
  Widget _dayCell(
    DateTime day, {
    Color? bgColor,
    required Color textColor,
    Color? borderColor,
  }) {
    return Center(
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: bgColor,
          shape: BoxShape.circle,
          // border: borderColor != null
          //     ? Border.all(color: borderColor, width: 1.5)
          //     : null,
        ),
        alignment: Alignment.center,
        child: Text(
          '${day.day}',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            fontFamily: AppFont.fontFamily,
            color: textColor,
          ),
        ),
      ),
    );
  }

  // ────────────────────────────────────────────────────────────────────────
  // EXISTING HELPERS (unchanged)
  // ────────────────────────────────────────────────────────────────────────
  Widget _detailGrid() {
    final size = MediaQuery.of(context).size;
    return Column(
      children: [
        _detailRow('Guests:', '4 Adults 2 Child'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Rooms:', '4 Rooms'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Washrooms:', '6 Washrooms'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Halls:', '2 Halls'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Outdoor Seating:', '1 Large Garden'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Pool:', '1 Private Swimming Pool'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Guard', 'Mohhamd'),
        SizedBox(height: size.height * 0.03),
        _detailRow('Pet Friendly', 'No'),
      ],
    );
  }

  Widget _detailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 14, fontFamily: AppFont.fontFamily, color: Colors.black87)),
        Text(value,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                fontFamily: AppFont.fontFamily,
                color: AppColor.primaryColor)),
      ],
    );
  }

  Widget _amenitiesGrid() {
    final size = MediaQuery.of(context).size;
    return GridView.builder(
      padding: EdgeInsets.zero,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: amenities.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 6,
      ),
      itemBuilder: (context, index) {
        final amenity = amenities[index];
        Widget iconWidget;
        switch (amenity) {
          case 'TV':
            iconWidget = Image.asset(AppImage.tvIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Wifi':
            iconWidget = Image.asset(AppImage.wifiIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'AC':
            iconWidget = Image.asset(AppImage.acIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Fridge':
            iconWidget = Image.asset(AppImage.fridgeIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Bedding':
            iconWidget = Image.asset(AppImage.beddingIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Microwave':
            iconWidget = Image.asset(AppImage.microwaveIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Kettle':
            iconWidget = Image.asset(AppImage.kettleIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          case 'Coffee Machine':
            iconWidget = Image.asset(AppImage.coffeeIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor); break;
          default:
            iconWidget = Image.asset(AppImage.tvIcon, width: size.width * 0.045, height: size.width * 0.045, color: AppColor.primaryColor);
        }
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            iconWidget,
            SizedBox(width: size.width * 0.015),
            Expanded(
              child: Text(amenity,
                  style: const TextStyle(
                      fontSize: 14,
                      fontFamily: AppFont.fontFamily,
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500),
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        );
      },
    );
  }

  Widget _guestCounterRow(BuildContext context,
      {required String label,
      required int count,
      required VoidCallback onDecrement,
      required VoidCallback onIncrement}) {
    final size = MediaQuery.of(context).size;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                fontFamily: AppFont.fontFamily,
                color: Colors.black87)),
        Row(
          children: [
            GestureDetector(
              onTap: onDecrement,
              child: Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(6)),
                child: const Icon(Icons.remove, size: 16, color: Colors.black87),
              ),
            ),
            SizedBox(width: size.width * 0.04),
            Text('$count',
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black)),
            SizedBox(width: size.width * 0.04),
            GestureDetector(
              onTap: onIncrement,
              child: Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(6)),
                child: const Icon(Icons.add, size: 16, color: Colors.black87),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _priceOption({
    required String title,
    required String price,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: size.height * 0.03),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: size.width * 0.05,
              height: size.width * 0.05,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColor.themeColor, width: 2)),
              child: isSelected
                  ? Center(
                      child: Container(
                        width: size.width * 0.025,
                        height: size.width * 0.025,
                        decoration: const BoxDecoration(
                            color: AppColor.themeColor, shape: BoxShape.circle),
                      ),
                    )
                  : null,
            ),
            SizedBox(width: size.width * 0.04),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          fontFamily: AppFont.fontFamily,
                          height: 1.4)),
                  SizedBox(height: size.height * 0.005),
                  Text(price,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: AppFont.fontFamily)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _legendItem(String label, Color? dotColor) {
    final size = MediaQuery.of(context).size;
    return Row(
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                fontFamily: AppFont.fontFamily,
                color: Colors.black87)),
        if (dotColor != null) ...[
          SizedBox(width: size.width * 0.015),
          Container(
            width: size.width * 0.035,
            height: size.width * 0.035,
            decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
          ),
        ],
      ],
    );
  }

  void _showCancellationPolicyDialog() {
    final size = MediaQuery.of(context).size;
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(16)),
          padding: EdgeInsets.all(size.width * 0.04),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                AppLanguage.cancellationPolicyText[language],
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppFont.fontFamily,
                    color: AppColor.themeColor),
              ),
              SizedBox(height: size.height * 0.015),
              Text(
                'Cancellations made more than 5 days before the check-in date will receive a full refund of the total booking amount. Cancellations made between 2 to 5 days before the check-in date will receive a 50% refund. No refunds will be issued for cancellations made within 2 days of the check-in date.',
                style: TextStyle(
                    fontSize: 13.8,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black87,
                    height: 1.5),
              ),
              SizedBox(height: size.height * 0.02),
            ],
          ),
        ),
      ),
    );
  }
}