import 'package:boatapp/controller/app_button.dart';
import 'package:boatapp/controller/app_color.dart';
import 'package:boatapp/controller/app_constant.dart';
import 'package:boatapp/controller/app_font.dart';
import 'package:boatapp/controller/app_header.dart';
import 'package:boatapp/controller/app_image.dart';
import 'package:boatapp/controller/app_language.dart';
import 'package:flutter/material.dart';


class PropertyBookingDetails extends StatelessWidget {
  const PropertyBookingDetails({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                    AppHeader(
                      text: AppLanguage.bookingDetailsText[language],
                      onPress: () {
                        Navigator.pop(context);
                      },
                    ),
                  
                // Status badge and View Details
                Container(
                  padding: EdgeInsets.symmetric(horizontal: size.width * 0.03, vertical: size.height * 0.01 ),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                            TextButton(
                              onPressed: () {},
                              child: const Text(
                                'View Details',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: AppFont.fontFamily,
                                  color: Color(0xFF17A2B8),
                                  decoration: TextDecoration.underline,
                                  decorationColor: AppColor.themeColor
                                ),
                              ),
                            ),
                          
                            const Text(
                              'The Greenleaf Inn',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                fontFamily: AppFont.fontFamily,
                                color: Colors.black,
                              ),
                            ),
                      ],
                    ),
                    Spacer(),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(
                        AppImage.subImage4,
                        width: size.width * 0.25,
                        height: size.height * 0.1,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
                ),

                SizedBox(height: size.height * 0.02),

                // Location Address
                 Text(
                  AppLanguage.locationAddressText[language],
                  style:const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    fontFamily: AppFont.fontFamily,
                    // color: Colors.grey.shade700,
                  ),
                ),
                SizedBox(height: size.height * 0.01 ),
                Text(
                  AppLanguage.southKutaText[language],
                  style:const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    fontFamily: AppFont.fontFamily,
                  ),
                ),
                SizedBox(height: size.height * 0.015),

                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset(
                    AppImage.mapImage,
                  ),
                ),
    
                 SizedBox(height: size.height * 0.02),

                // Booking Details
                Text(
                  AppLanguage.bookingDetailsText[language],
                  style:const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black,
                  ),
                ),
             SizedBox(height: size.height * 0.02),

                _detailRow(
                  context,
                  AppImage.dateTimeIcon,
                  'Jan 06, 2025',
                  'Booking Date',
                  'Change',
                ),
                SizedBox(height: size.height * 0.02),
                _detailRow(
                  context,
                  AppImage.bookingTime,
                  '1 Day',
                  'Booking Time',
                  'Change',
                ),
                SizedBox(height: size.height * 0.02),
                _detailRow(
                  context,
                  AppImage.guestsIcon,
                  '4 Adults 2 Children',
                  'Guests',
                  'Change',
                ),
                SizedBox(height: size.height * 0.03),

                // Description
                const Text(
                  'Description',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  'Blue Nature is a 5 star complemented with 80 well bedroom and suit, modern residence with prime location within the city center.',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.grey.shade700,
                    height: 1.5,
                  ),
                ),
                SizedBox(height: 24),

                // Add-ons
                const Text(
                  'Add-ons',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 12),

                _addonItem('Entertainment (2)', '10 KWD', 2),
                SizedBox(height: 12),
                _addonItem('Life Jackets', '10 KWD', 2),
                SizedBox(height: 12),
                _addonItem('Food(1)', '', 0),
                SizedBox(height: 8),
                _addonItem('Samboosa', '10 KWD', 2),
                const SizedBox(height: 24),

                Text(
                  AppLanguage.billingDetailsText[language],
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.black,
                  ),
                ),
                // SizedBox(height: 16),

                // _billingRow('4 hours', '64 KWD', 'Rice: 56789056'),
                // SizedBox(height: 12),
                // _billingRow('Add-Ons', '50 KWD', ''),
                // SizedBox(height: 8),
                // Padding(
                //   padding: EdgeInsets.only(left: 16),
                //   child: Column(
                //     children: [
                //       _billingSubRow('Entertainment', '30 KWD'),
                //       SizedBox(height: 4),
                //       _billingSubRow('Food', '10 KWD'),
                //     ],
                //   ),
                // ),
                SizedBox(height: 12),
                _billingRow('1 Day', '64 KWD', ''),
                Divider(height: 32),
                _billingRow('Grand Total', '64 KWD', '', isBold: true),
                SizedBox(height: 36),

                AppButton(text:'Chat', onPress: (){}),
                SizedBox(height: 16),
                 AppButton(text:'Location', onPress: (){}),

                 SizedBox(height: 16,),
                // Cancel Booking
                InkWell(
                  onTap: () {},
                  child: Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColor.secondaryColor,
                      borderRadius: BorderRadius.circular(25),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: 
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Cancel',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              fontFamily: AppFont.fontFamily,
                              // color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  )
                ),
                SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detailRow(BuildContext context, String image, String value, String label, String action) {
    final size = MediaQuery.of(context).size;

    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Color(0xFF17A2B8).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Image.asset(
            image,  
            width: size.width*0.02,
            height: size.height*0.02
            ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  fontFamily: AppFont.fontFamily,
                  // color: Colors.black,
                ),
              ),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  fontFamily: AppFont.fontFamily,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
        TextButton(
          onPressed: () {},
          child: Text(
            action,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              fontFamily: AppFont.fontFamily,
              color:AppColor.primaryColor,
              decoration: TextDecoration.underline,
            ),
          ),
        ),
      ],
    );
  }

  Widget _addonItem(String title, String price, int quantity) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.grey.shade300,
          ),
          child: Icon(Icons.image, color: Colors.grey.shade500),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: AppFont.fontFamily,
              color: Colors.black87,
            ),
          ),
        ),
        if (quantity > 0)
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              'Qty: $quantity',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                fontFamily: AppFont.fontFamily,
                color: Colors.black87,
              ),
            ),
          ),
        if (price.isNotEmpty) ...[
          SizedBox(width: 8),
          Text(
            price,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: AppFont.fontFamily,
              color: Colors.black,
            ),
          ),
        ],
      ],
    );
  }

  Widget _billingRow(String label, String amount, String subtitle,
      {bool isBold = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
                fontFamily: AppFont.fontFamily,
                color: Colors.black,
              ),
            ),
            Text(
              amount,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isBold ? FontWeight.w700 : FontWeight.w600,
                fontFamily: AppFont.fontFamily,
                color: Colors.black,
              ),
            ),
          ],
        ),
        if (subtitle.isNotEmpty) ...[
          SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              fontFamily: AppFont.fontFamily,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ],
    );
  }

  Widget _billingSubRow(String label, String amount) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            fontFamily: AppFont.fontFamily,
            color: Colors.grey.shade700,
          ),
        ),
        Text(
          amount,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            fontFamily: AppFont.fontFamily,
            color: Colors.grey.shade700,
          ),
        ),
      ],
    );
  }
}
