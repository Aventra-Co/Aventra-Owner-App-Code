import 'package:boatapp/controller/app_color.dart';
import 'package:boatapp/controller/app_constant.dart';
import 'package:boatapp/controller/app_font.dart';
import 'package:boatapp/controller/app_image.dart';
import 'package:boatapp/controller/app_language.dart';
import 'package:flutter/material.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  String selectedOption = "Sea";

  List<Map<String, dynamic>> get currentBookings =>
      selectedOption == "Sea" ? seaBookings : propertyBookings;

  // Sea bookings data
  final List<Map<String, dynamic>> seaBookings = [
    {
      'date': '06',
      'month': 'Jan',
      'year': '2025',
      'title': 'Ocean Explorer 3000',
      'subtitle': 'Luxury Yacht • Fintas Beach',
      'startTime': '08:00 AM',
      'duration': '4 Hours',
      'status': 'Pending',
      'statusColor': AppColor.pendingColor,
    },
    {
      'date': '02',
      'month': 'Jan',
      'year': '2025',
      'title': 'Ocean Explorer 3000',
      'subtitle': 'Fishing Boat • Fintas Beach',
      'startTime': '08:00 AM',
      'duration': '4 Hours',
      'status': 'Ongoing',
      'statusColor': AppColor.ongoingColor,
    },
    {
      'date': '02',
      'month': 'Jan',
      'year': '2025',
      'title': 'Ocean Explorer 3000',
      'subtitle': 'Fishing Boat • Fintas Beach',
      'startTime': '08:00 AM',
      'duration': '4 Hours',
      'status': 'Completed',
      'statusColor': AppColor.themeColor,
    },
  ];

  // Property bookings data
  final List<Map<String, dynamic>> propertyBookings = [
    {
      'date': '06',
      'month': 'Jan',
      'year': '2025',
      'title': 'The Greenleaf Inn',
      'subtitle': 'South Kuta',
      'booking': 'Booking',
      'duration': '1 Day',
      'status': 'Pending',
      'statusColor': AppColor.pendingColor,
    },
    {
      'date': '02',
      'month': 'Jan',
      'year': '2025',
      'title': 'The Greenleaf Inn',
      'subtitle': 'South Kuta',
      'booking': 'Booking',
      'duration': '1 Day',
      'status': 'Ongoing',
      'statusColor': AppColor.ongoingColor,
    },
    {
      'date': '01',
      'month': 'Jan',
      'year': '2025',
      'title': 'The Greenleaf Inn',
      'subtitle': 'South Kuta',
      'booking': 'Booking',
      'duration': '1 Day',
      'status': 'Completed',
      'statusColor': AppColor.completedColor,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            height: size.height,
            width: size.width,
            child: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: size.width * 0.03, vertical: size.height * 0.03),
              child: Column(
                children: [
                  //Header
                  Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: size.width * 0.03),
                      child: Row(
                        children: [
                          Text(
                            AppLanguage.bookingsText[language],
                            style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                fontFamily: AppFont.fontFamily),
                          ),
                          const Spacer(),
                          Material(
                            elevation: 5,
                            shape: const CircleBorder(),
                            color: AppColor.secondaryColor,
                            child: IconButton(
                              onPressed: () {
                           
                                _showFilterModal(context, selectedOption);
                              },
                              icon: Image.asset(
                                AppImage.filterAndSortIcon,
                                width: size.width * 0.05,
                                height: size.height * 0.05,
                              ),
                            ),
                          ),
                        ],
                      )),

                  SizedBox(height: size.height * 0.03),
                  // Toggle buttons
                  Row(
                    children: [
                      Expanded(
                        child: _toggleButton("Sea"),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _toggleButton("Property"),
                      ),
                    ],
                  ),
                  SizedBox(height: 24),

                  // Bookings list
                  Expanded(
                    child: ListView.builder(
                      itemCount: currentBookings.length,
                      itemBuilder: (context, index) {
                        final booking = currentBookings[index];
                        return selectedOption == "Sea"
                            ? _seaBookingCard(booking)
                            : _propertyBookingCard(booking);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _toggleButton(String option) {
    final isSelected = selectedOption == option;
    final size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedOption = option;
        });
      },
      child: Container(
        width: size.width * 0.45,
        height: size.height * 0.045,
        padding: EdgeInsets.symmetric(
            vertical: size.height * 0.01, horizontal: size.height * 0.02),
        decoration: BoxDecoration(
          color: isSelected ? AppColor.themeColor : AppColor.secondaryColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: AppColor.themeColor,
            width: 0.8,
          ),
        ),
        child: Text(
          option,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            fontFamily: AppFont.fontFamily,
            color: isSelected ? AppColor.secondaryColor : AppColor.primaryColor,
          ),
        ),
      ),
    );
  }

  Widget _seaBookingCard(Map<String, dynamic> booking) {
    final size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () {
        // Navigator.push(context, MaterialPageRoute(builder: (context) => SeaDetailsScreen()));
      },
      child: Container(
        margin: EdgeInsets.symmetric(
            vertical: size.height * 0.01, horizontal: size.width * 0.02),
        child: Row(
          children: [
            // Date section (left teal box)
            Container(
              width: size.width * 0.2,
              padding: EdgeInsets.symmetric(
                  vertical: size.height * 0.02, horizontal: size.width * 0.02),
              decoration: BoxDecoration(
                color: AppColor.themeColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Text(
                    booking['month'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: AppFont.fontFamily,
                      color: AppColor.secondaryColor,
                    ),
                  ),
                  Text(
                    booking['date'],
                    style: const TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w500,
                      fontFamily: AppFont.fontFamily,
                      color: AppColor.secondaryColor,
                    ),
                  ),
                  Text(
                    booking['year'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: AppFont.fontFamily,
                      color: AppColor.secondaryColor,
                    ),
                  ),
                ],
              ),
            ),

            // Content section
            SizedBox(width: size.width * 0.02),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.symmetric(
                    horizontal: size.width * 0.03,
                    vertical: size.height * 0.02),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                booking['title'],
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: AppFont.fontFamily,
                                  color: Colors.black,
                                ),
                              ),
                              Text(
                                booking['subtitle'],
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppFont.fontFamily,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Arrow icon
                        Padding(
                          padding: EdgeInsets.symmetric(),
                          child: Image.asset(
                            AppImage.rightArrow,
                            color: AppColor.primaryColor,
                            width: size.width * 0.07,
                            height: size.height * 0.07,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: size.height * 0.01),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Start time
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              booking['startTime'] ?? '',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: Colors.black87,
                              ),
                            ),
                            Text(
                              'Start Time',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                        // Duration
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              booking['duration'],
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: AppColor.primaryColor,
                              ),
                            ),
                            Text(
                              'Booking Hours',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                        // Status
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              booking['status'],
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: booking['statusColor'],
                              ),
                            ),
                            Text(
                              'Status',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppFont.fontFamily,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _propertyBookingCard(Map<String, dynamic> booking) {
    final size = MediaQuery.of(context).size;

    return GestureDetector(
        onTap: () {
          // Navigator.push(context, MaterialPageRoute(builder: (context) => PropertyDetailScreen()));
        },
        child: Container(
          margin: EdgeInsets.symmetric(
              vertical: size.height * 0.01, horizontal: size.width * 0.02),
          child: Row(
            children: [
              // Date section (left teal box)
              Container(
                width: size.width * 0.2,
                padding: EdgeInsets.symmetric(
                    vertical: size.height * 0.02,
                    horizontal: size.width * 0.02),
                decoration: BoxDecoration(
                  color: AppColor.themeColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      booking['month'],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor,
                      ),
                    ),
                    Text(
                      booking['date'],
                      style: const TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor,
                      ),
                    ),
                    Text(
                      booking['year'],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor,
                      ),
                    ),
                  ],
                ),
              ),

              // Content section
              SizedBox(width: size.width * 0.02),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: EdgeInsets.symmetric(
                      horizontal: size.width * 0.03,
                      vertical: size.height * 0.02),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  booking['title'],
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: AppFont.fontFamily,
                                    color: Colors.black,
                                  ),
                                ),
                                Text(
                                  booking['subtitle'],
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: AppFont.fontFamily,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Arrow icon
                          Padding(
                            padding: EdgeInsets.symmetric(),
                            child: Image.asset(
                              AppImage.rightArrow,
                              color: AppColor.primaryColor,
                              width: size.width * 0.07,
                              height: size.height * 0.07,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: size.height * 0.01),
                      Row(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Duration / Booking
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                booking['duration'] ?? '',
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppFont.fontFamily,
                                  color: Colors.black87,
                                ),
                              ),
                              Text(
                                'Booking',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppFont.fontFamily,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),

                          SizedBox(width: size.width * 0.15),
                          // Status
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                booking['status'],
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppFont.fontFamily,
                                  color: booking['statusColor'],
                                ),
                              ),
                              Text(
                                'Status',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppFont.fontFamily,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  Widget _propertyTypeCard(String imagePath, String label) {
    final size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () {
        // Navigator.push(context, MaterialPageRoute(builder: (context) => PropertyDetailScreen()));
      },
      child: Column(
        children: [
          // Image card
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                border: selectedOption == 'Property'
                    ? Border.all(color: AppColor.boxshadowColor)
                    : null,
                image: DecorationImage(
                  image: AssetImage(imagePath),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SizedBox(height: size.height * 0.01),
          // Label
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              fontFamily: AppFont.fontFamily,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterModal(BuildContext context, String currentTab) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColor.transparentColor,
      builder: (context) {
        return GestureDetector(
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    currentTab == "Sea"
                        ? AppLanguage.selectSeaTypeText[language]
                        : "${AppLanguage.selectPropertyTypeText[language]}:",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppFont.fontFamily,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Grid of property types
                GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 3,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 0.85,
                  physics: const NeverScrollableScrollPhysics(),
           children: currentTab == "Sea"
                      ? [
                          _propertyTypeCard(
                              AppImage.parasailingImage, 'Parasailing'),
                          _propertyTypeCard(
                              AppImage.snorkelingImage, 'Snorkelling'),
                          _propertyTypeCard(AppImage.divingImage, 'Diving'),
                          _propertyTypeCard(
                              AppImage.parasailingImage, 'Parasailing'),
                          _propertyTypeCard(
                              AppImage.snorkelingImage, 'Snorkelling'),
                          _propertyTypeCard(
                              AppImage.parasailingImage, 'Diving'),
                        ]
                      : [
                          _propertyTypeCard(
                            AppImage.privateVillaImage,
                            'Private Villa',
                          ),
                          _propertyTypeCard(
                            AppImage.chaletIstirahaImage,
                            'Chalet / Istiraha',
                          ),
                          _propertyTypeCard(
                            AppImage.luxuryVillaIcon,
                            'Luxury Villa',
                          ),
                          _propertyTypeCard(
                            AppImage.farmHouseImage,
                            'Farmhouse',
                          ),
                          _propertyTypeCard(
                            AppImage.resortVillaImage,
                            'Resort Villa',
                          ),
                          _propertyTypeCard(
                            AppImage.tentInDesertImage,
                            'Tent in desert',
                          ),
                        ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        );
      },
    );
  }


}
