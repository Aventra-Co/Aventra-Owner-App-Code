import 'package:boatapp/controller/app_color.dart';
import 'package:boatapp/controller/app_constant.dart';
import 'package:boatapp/controller/app_font.dart';
import 'package:boatapp/controller/app_header.dart';
import 'package:boatapp/controller/app_image.dart';
import 'package:boatapp/controller/app_language.dart';
import 'package:boatapp/model/property_model.dart';
import 'package:boatapp/model/sort_model.dart';
import 'package:flutter/material.dart';
import 'package:boatapp/view/property_screens/property_detail_screen.dart';
import 'package:flutter/services.dart';

class PropertyHomeScreen extends StatefulWidget {
  final String initialView;

  const PropertyHomeScreen({super.key, this.initialView = "List"});

  @override
  State<PropertyHomeScreen> createState() => _PropertyHomeScreenState();
}

class _PropertyHomeScreenState extends State<PropertyHomeScreen> {
  late String selectedView;

  // ── Search ────────────────────────────────────────────────────────────
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedPropertyType = '';

  List<Map<String, dynamic>> get _filteredProperties {
    if (_searchQuery.isEmpty) return properties;
    return properties
        .where((p) =>
            p['name']
                .toString()
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()) ||
            p['location']
                .toString()
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()))
        .toList();
  }
  // ─────────────────────────────────────────────────────────────────────

  final List<Map<String, dynamic>> properties = [
    {
      'name': 'The Greenleaf Inn',
      'location': 'Jeddah - Obhur',
      'price': '16 KWD',
      'image': AppImage.greenLeafImage,
      'isFavorite': false,
    },
    {
      'name': 'Sunset Farmhouse',
      'location': 'Dhiyah - Riyadh',
      'price': '16 KWD',
      'image': AppImage.farmHouseImage,
      'isFavorite': false,
    },
    {
      'name': 'Palm Resort Chalet',
      'location': 'Jeddah - Obhur',
      'price': '16 KWD',
      'image': AppImage.palmResortImage,
      'isFavorite': false,
    },
    {
      'name': 'The Greenleaf Inn',
      'location': 'Jeddah - Obhur',
      'price': '16 KWD',
      'image': AppImage.greenLeafImage,
      'isFavorite': false,
    },
    {
      'name': 'Sunset Farmhouse',
      'location': 'Dhiyah - Riyadh',
      'price': '16 KWD',
      'image': AppImage.farmHouseImage,
      'isFavorite': false,
    },
    {
      'name': 'Palm Resort Chalet',
      'location': 'Jeddah - Obhur',
      'price': '16 KWD',
      'image': AppImage.palmResortImage,
      'isFavorite': false,
    },
  ];

  @override
  void initState() {
    super.initState();
    selectedView = widget.initialView;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: AppColor.transparentColor,
        statusBarIconBrightness: Brightness.dark));

    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: AppColor.secondaryColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // ── Header ───────────────────────────────────────────────
              AppHeader(
                text: AppLanguage.mostPopularpropertiesText[language],
                onPress: () => Navigator.pop(context),
              ),

              SizedBox(height: size.height * 0.01),

              // ── Search Bar ───────────────────────────────────────────
              _buildSearchBar(size),

              SizedBox(height: size.height * 0.035),

              // ── Grid ─────────────────────────────────────────────────
              _filteredProperties.isEmpty
                  ? Padding(
                      padding: EdgeInsets.only(top: size.height * 0.1),
                      child: Column(
                        children: [
                          Icon(Icons.search_off,
                              size: 60, color: Colors.grey.shade300),
                          const SizedBox(height: 12),
                          Text(
                            'No properties found',
                            style: TextStyle(
                              fontSize: 16,
                              fontFamily: AppFont.fontFamily,
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    )
                  : GridView.builder(
                      padding:
                          EdgeInsets.symmetric(horizontal: size.width * 0.04),
                      itemCount: _filteredProperties.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 0.75,
                      ),
                      itemBuilder: (context, index) {
                        return _propertyGridCard(
                            _filteredProperties[index], index);
                      },
                    ),

              SizedBox(height: size.height * 0.1),
            ],
          ),
        ),
      ),
    );
  }

  // ── Search Bar Widget ─────────────────────────────────────────────────
  Widget _buildSearchBar(Size size) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
      child: Row(
        children: [
          // Search Field
          Expanded(
            child: Container(
              height: size.height * 0.060,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(40),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.12),
                    blurRadius: 20,
                    spreadRadius: 2,
                    offset: const Offset(0, 6),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextFormField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() => _searchQuery = value);
                },
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w400,
                  fontFamily: AppFont.fontFamily,
                  color: AppColor.primaryColor,
                ),
                decoration: InputDecoration(
                  hintText: 'Search',
                  hintStyle: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppFont.fontFamily,
                    color: Colors.grey.shade400,
                  ),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.only(left: 16, right: 8),
                    child: Icon(
                      Icons.search,
                      color: Colors.grey.shade400,
                      size: 22,
                    ),
                  ),
                  prefixIconConstraints: const BoxConstraints(
                    minWidth: 48,
                    minHeight: 48,
                  ),
                  // Clear button when text is entered
                  suffixIcon: _searchQuery.isNotEmpty
                      ? GestureDetector(
                          onTap: () {
                            _searchController.clear();
                            setState(() => _searchQuery = '');
                          },
                          child: Icon(Icons.close,
                              color: Colors.grey.shade400, size: 18),
                        )
                      : null,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  counterText: '',
                ),
              ),
            ),
          ),

          SizedBox(width: size.width * 0.03),

          // Filter Button
          GestureDetector(
            onTap: () {
              showFilterModal(context);
            },
            child: Container(
              width: size.height * 0.055,
              height: size.height * 0.055,
              decoration: BoxDecoration(
                color: AppColor.themeColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppColor.themeColor.withOpacity(0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.tune_rounded,
                color: Colors.white,
                size: 22,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── View Toggle Button ────────────────────────────────────────────────
  Widget _viewButton(String label, String activeImage, String inactiveImage) {
    final isSelected = selectedView == label;
    return GestureDetector(
      onTap: () => setState(() => selectedView = label),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColor.themeColor : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              isSelected ? activeImage : inactiveImage,
              width: 18,
              height: 18,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 16,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                fontFamily: AppFont.fontFamily,
                color: isSelected
                    ? AppColor.secondaryColor
                    : AppColor.textLightColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── List Card ─────────────────────────────────────────────────────────
  Widget _propertyCard(Map<String, dynamic> property, int index) {
    final size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const PropertyDetailsScreen()),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: AssetImage(property['image']),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              right: 12,
              child: GestureDetector(
                onTap: () => setState(() {
                  properties[index]['isFavorite'] =
                      !properties[index]['isFavorite'];
                }),
                child: Container(
                  width: size.width * 0.07,
                  height: size.height * 0.07,
                  decoration: const BoxDecoration(
                    color: AppColor.secondaryColor,
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(
                    property['isFavorite']
                        ? AppImage.removeFavouriteIcon
                        : AppImage.addFavouriteIcons,
                    width: size.width * 0.07,
                    height: size.width * 0.07,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(property['name'],
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          fontFamily: AppFont.fontFamily,
                          color: AppColor.secondaryColor)),
                  const SizedBox(height: 4),
                  Text(property['location'],
                      style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          fontFamily: AppFont.fontFamily,
                          color: AppColor.secondaryColor)),
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: const BoxDecoration(
                  color: AppColor.themeColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                ),
                child: Text.rich(TextSpan(children: [
                  TextSpan(
                    text: property['price'],
                    style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor),
                  ),
                  const TextSpan(
                    text: '/Day',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor),
                  ),
                ])),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Grid Card ─────────────────────────────────────────────────────────
  Widget _propertyGridCard(Map<String, dynamic> property, int index) {
    final size = MediaQuery.of(context).size;

    // find real index in original list for favorite toggle
    final realIndex = properties.indexOf(property);

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const PropertyDetailsScreen()),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: AssetImage(property['image']),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            // Gradient overlay
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
            ),

            // Price badge
            Positioned(
              top: 0,
              left: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: const BoxDecoration(
                  color: AppColor.themeColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                ),
                child: Text.rich(TextSpan(children: [
                  TextSpan(
                    text: property['price'],
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor),
                  ),
                  const TextSpan(
                    text: '/Day',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor),
                  ),
                ])),
              ),
            ),

            // Counter badge
            Positioned(
              top: 5,
              right: 5,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColor.secondaryColor.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text('1/6',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppFont.fontFamily,
                        color: AppColor.secondaryColor)),
              ),
            ),

            // Name & location
            Positioned(
              bottom: 8,
              left: 8,
              right: 35,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(property['name'],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: AppFont.fontFamily,
                          color: Colors.white)),
                  const SizedBox(height: 4),
                  Text(property['location'],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w400,
                          fontFamily: AppFont.fontFamily,
                          color: Colors.white.withOpacity(0.9))),
                ],
              ),
            ),

            // Favourite icon
            Positioned(
              bottom: 12,
              right: 8,
              child: GestureDetector(
                onTap: () {
                  if (realIndex != -1) {
                    setState(() {
                      properties[realIndex]['isFavorite'] =
                          !properties[realIndex]['isFavorite'];
                    });
                  }
                },
                child: Image.asset(
                  property['isFavorite']
                      ? AppImage.removeFavouriteIcon
                      : AppImage.addFavouriteIcons,
                  width: size.width * 0.05,
                  height: size.width * 0.05,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Map View ──────────────────────────────────────────────────────────
  Widget _buildMapView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Image.asset(AppImage.mapImage2)],
      ),
    );
  }
// ── Selected filter state ────────────────────────────────────────────

  // ── Filter Modal ──────────────────────────────────────────────────────
  void showFilterModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColor.transparentColor,
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Title
                  const Text(
                    'Select property type',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppFont.fontFamily,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Grid of property types
                  GridView.count(
                    shrinkWrap: true,
                    crossAxisCount: 3,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 0.85,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.privateVillaImage,
                        label: 'Private Villa',
                      ),
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.chaletIstirahaImage,
                        label: 'Chalet / Istiraha',
                      ),
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.luxuryVillaIcon,
                        label: 'Luxury Villa',
                      ),
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.farmHouseImage,
                        label: 'Farm House',
                      ),
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.resortVillaImage,
                        label: 'Resort Villa',
                      ),
                      _propertyTypeCard(
                        context: context,
                        setModalState: setModalState,
                        imagePath: AppImage.tentInDesertImage,
                        label: 'Tent in Desert',
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ── Property Type Card ────────────────────────────────────────────────
  Widget _propertyTypeCard({
    required BuildContext context,
    required StateSetter setModalState,
    required String imagePath,
    required String label,
  }) {
    final size = MediaQuery.of(context).size;
    final isSelected = _selectedPropertyType == label;

    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
      },
      child: Column(
        children: [
          // Image card
          Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                // border: Border.all(
                //   color: isSelected
                //       ? AppColor.themeColor
                //       : AppColor.boxshadowColor,
                //   width: isSelected ? 2.5 : 1,
                // ),
                // boxShadow: isSelected
                //     ? [
                //         BoxShadow(
                //           color: AppColor.themeColor.withOpacity(0.25),
                //           blurRadius: 8,
                //           spreadRadius: 1,
                //         )
                //       ]
                //     : [],
                image: DecorationImage(
                  image: AssetImage(imagePath),
                  fit: BoxFit.cover,
                  // Darken slightly when NOT selected so selected pops
                  // colorFilter: isSelected
                  //     ? null
                  //     : ColorFilter.mode(
                  //         Colors.black.withOpacity(0.15),
                  //         BlendMode.darken,
                  //       ),
                ),
              ),
            ),
          ),
          SizedBox(height: size.height * 0.008),
          // Label
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              fontFamily: AppFont.fontFamily,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}
