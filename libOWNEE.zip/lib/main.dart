import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:provider/provider.dart';
import 'controller/app_color.dart';
import 'controller/app_connectivity.dart';
import 'controller/app_constant.dart';
import 'controller/app_font.dart';
import 'controller/one_signal_service.dart';
import 'controller/route_observer.dart';
import 'controller/routes.dart';
import 'view/authentication/splash_screen.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: AppColor.secondaryColor,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
    ),
  );

  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // v5: initialize replaces shared.setAppId
  await initOneSignal(AppConstant.oneSignalAppId);
  await OneSignalService.initOneSignal();

  runApp(const MyApp());

  await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: AppConstant.apiKey,
          appId: AppConstant.appId,
          messagingSenderId: AppConstant.messagingSenderId,
          projectId: AppConstant.projectId));
}

Future<void> initOneSignal(String oneSignalAppId) async {
  print("initOneSignal ------ ");

  // v5: initialize() replaces shared.setAppId()
  OneSignal.initialize(oneSignalAppId);

  // v5: requestPermission() replaces promptUserForPushNotificationPermission()
  OneSignal.Notifications.requestPermission(true).then((accepted) {
    print("Accepted permission: $accepted");
  });

  // v5: push subscription ID replaces getDeviceState().userId
  final subscriptionId = OneSignal.User.pushSubscription.id;
  if (subscriptionId != null) {
    AppConstant.playerID = subscriptionId;
    print("playerID: ${AppConstant.playerID}");
  }

  // v5: observe subscription changes to catch ID once available
  // replaces the Timer.periodic polling loop
  OneSignal.User.pushSubscription.addObserver((state) {
    final newId = state.current.id;
    if (newId != null && newId.isNotEmpty) {
      AppConstant.playerID = newId;
      print("pushSubscription ID updated: $newId");
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) => ConnectionProvider()..initialize()),
      ],
      child: MaterialApp(
        navigatorObservers: [routeObserver],
        title: 'Aventra Owner',
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: AppColor.themeColor),
          fontFamily: AppFont.fontFamily,
        ),
        routes: routes,
        home: const AppInitializer(),
      ),
    );
  }
}

class AppInitializer extends StatefulWidget {
  const AppInitializer({super.key});

  @override
  _AppInitializerState createState() => _AppInitializerState();
}

class _AppInitializerState extends State<AppInitializer> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      OneSignalService.setAppInitialized(true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Splash();
  }
}