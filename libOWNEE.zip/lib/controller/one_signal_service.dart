import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../chat/chat_screen.dart';
import '../main.dart';
import '../model/chat_user.dart';
import '../view/other_screen/notification.dart';
import 'app_constant.dart';

class OneSignalService {
  static Map<String, dynamic>? _pendingNotificationData;
  static bool _hasPendingBroadcast = false;
  static bool _isAppInitialized = false;

  static Future<void> initOneSignal() async {
    print("Initializing OneSignal");

    // v5: initialize() replaces shared.setAppId()
    OneSignal.initialize(AppConstant.oneSignalAppId);

    // v5: push subscription ID replaces getDeviceState().userId
    final subscriptionId = OneSignal.User.pushSubscription.id;
    if (subscriptionId != null) {
      AppConstant.playerID = subscriptionId;
      print("playerID: ${AppConstant.playerID}");
    }

    // v5: observe subscription changes to catch ID once SDK registers
    OneSignal.User.pushSubscription.addObserver((state) {
      final newId = state.current.id;
      if (newId != null && newId.isNotEmpty) {
        AppConstant.playerID = newId;
        print("pushSubscription ID updated: $newId");
      }
    });

    // v5: addClickListener replaces setNotificationOpenedHandler
    // OSNotificationClickEvent replaces OSNotificationOpenedResult
    OneSignal.Notifications.addClickListener(
        (OSNotificationClickEvent event) async {
      print("Notification click event: ${event.toString()}");
      print('additionalData: ${event.notification.additionalData}');

      final additionalData = event.notification.additionalData;

      if (additionalData != null) {
        _pendingNotificationData = additionalData;

        if (_isAppInitialized) {
          _handleNotificationNavigation(additionalData);
        } else {
          _storePendingNotification(additionalData);
        }
      }
    });
  }

  static void _storePendingNotification(Map<String, dynamic> additionalData) {
    try {
      var decodeData =
          json.decode(json.encode(additionalData))['action_json']['action'];

      if (decodeData.toString().toLowerCase() == "broadcast") {
        print("Storing pending broadcast notification");
        _hasPendingBroadcast = true;
      }
    } catch (e) {
      print("Error storing pending notification: $e");
    }
  }

  static void _handleNotificationNavigation(
      Map<String, dynamic> additionalData) {
    print("Handling notification navigation");
    try {
      var decodeData =
          json.decode(json.encode(additionalData))['action_json']['action'];

      print("Action: $decodeData");

      if (decodeData.toString().toLowerCase() == "broadcast" ||
          decodeData.toString().toLowerCase() == "trip_booking" ||
          decodeData.toString().toLowerCase() == "property_booking" ||
          decodeData.toString().toLowerCase() == "property_cancellation" ||
          decodeData.toString().toLowerCase() == "trip_cancellation") {
        print("Broadcast action received");

        if (navigatorKey.currentState != null &&
            navigatorKey.currentContext != null &&
            _isAppInitialized) {
          navigatorKey.currentState?.push(
            MaterialPageRoute(
              builder: (_) => const Notifications(),
            ),
          );
          clearPendingNotifications();
        } else {
          print(
              "Navigator not ready or app not initialized, storing for later");
          _hasPendingBroadcast = true;
        }
      }

      if (decodeData.toString() == "FLUTTER_NOTIFICATION_CLICK") {
        print("Follow action received");

        var otheruserId =
            json.decode(json.encode(additionalData))['action_json']['userId'];
        print("otheruserId: $otheruserId");

        bool isNavigated = false;
        FirebaseFirestore.instance
            .collection("users")
            .where("id", isEqualTo: otheruserId)
            .get()
            .then((snapshot) {
          if (snapshot.docs.isNotEmpty) {
            var data = snapshot.docs.first.data();
            ChatUser user = ChatUser.fromJson(data);

            if (!isNavigated &&
                navigatorKey.currentState != null &&
                _isAppInitialized) {
              isNavigated = true;
              navigatorKey.currentState?.push(
                MaterialPageRoute(
                  builder: (_) => ChatScreen(user: user),
                ),
              );
              clearPendingNotifications();
            }
          } else {
            print("User not found in Firestore.");
          }
        }).catchError((error) {
          print("Error fetching user: $error");
        });
      }
    } catch (e) {
      print("Error handling notification: $e");
    }
  }

  static bool hasPendingBroadcastNotification() {
    return _hasPendingBroadcast;
  }

  static void handlePendingNotifications() {
    _isAppInitialized = true;
    if (_pendingNotificationData != null) {
      print("Processing pending notification after app initialization");
      _handleNotificationNavigation(_pendingNotificationData!);
    }
  }

  static void clearPendingNotifications() {
    _pendingNotificationData = null;
    _hasPendingBroadcast = false;
  }

  static void navigateToNotifications(BuildContext context) {
    if (_hasPendingBroadcast) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const Notifications()),
      );
      clearPendingNotifications();
    }
  }

  static void setAppInitialized(bool initialized) {
    _isAppInitialized = initialized;
  }
}
